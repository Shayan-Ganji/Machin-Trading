import pandas as pd
import numpy as np
import re
from sklearn.preprocessing import LabelEncoder
import os

def prepare_data(df):
    if df is None or df.empty:
        print("Warning: Input DataFrame is empty or None")
        return pd.DataFrame()  # برگرداندن DataFrame خالی به جای None

    df = df.rename(columns=lambda x: re.sub('[^A-Za-z0-9_]+', '', x))
    df['date_m'] = pd.to_datetime(df['date_m'], errors='coerce')
    df = df.dropna(subset=['date_m'])
    df = df.sort_values('date_m')

    for c in df.columns:
        if df[c].dtype == 'object':
            LE = LabelEncoder()
            class_file_path = f'D:\\Desktop\\Time\\classes_{c}.npy'
            if os.path.exists(class_file_path):
                LE.classes_ = np.load(class_file_path, allow_pickle=True)
                df = df[df[c].isin(LE.classes_)]
                df[c] = LE.transform(df[c])
            else:
                print(f"Warning: Class file for {c} not found. Encoding skipped.")

    return df

def create_target(df, upper_bound=1.07, lower_bound=1.0):
    """
    ایجاد ستون هدف با توجه به پارامترهای بالایی و پایینی برای تعیین سیگنال خرید
    """

    # افزودن ستون هدف برای پیش‌بینی
    df['target_'] = -1
    df.loc[df['target_max'] > upper_bound, 'target_'] = 1
    df.loc[(df['target_max'] <= upper_bound) & (df['target_end'] < lower_bound), 'target_'] = 0
    
    return df

def X_y_split(df):
    """
    جدا کردن X و y از مجموعه داده اصلی برای مدل‌سازی
    """

    # جدا کردن متغیرهای ورودی (X) و خروجی (y)
    X = df.drop(['target_max', 'target_end', 'target_', 'date_m'], axis=1, errors='ignore')
    Y = df['target_']
    
    # حذف نمونه‌هایی که هدف ندارند (target_ = -1)
    X = X[Y != -1]
    Y = Y[Y != -1]

    return X, Y
