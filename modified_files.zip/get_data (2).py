
import pandas as pd
import numpy as np
import sys
import io
import matplotlib.pyplot as plt
import pytse_client as tse
from tqdm import tqdm
from pytse_client import download_client_types_records
from pytse_client.scraper import symbol_scraper
import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry
from glob import glob
import shutil
import os
import re


ticker_index_path = r"D:\Desktop\python\ticker_index.csv"
new_info_path = r"D:\Desktop\python\new_info.csv"

def requests_retry_session(retries=10, backoff_factor=0.3, status_forcelist=(500, 502, 504, 503), session=None) -> requests.Session:
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session

def clean_sentence(sentence):
    sentence = arToPersianChar(sentence)
    sentence = arToPersianNumb(sentence)
    return sentence

def arToPersianNumb(number):
    dic = {
        '١': '۱', '٢': '۲', '٣': '۳', '٤': '۴', '٥': '۵', '٦': '۶',
        '٧': '۷', '٨': '۸', '٩': '۹', '٠': '۰',
    }
    return multiple_replace(dic, number)

def arToPersianChar(userInput):
    dic = {
        'ك': 'ک', 'دِ': 'د', 'بِ': 'ب', 'زِ': 'ز', 'ذِ': 'ذ',
        'شِ': 'ش', 'سِ': 'س', 'ى': 'ی', 'ي': 'ی'
    }
    return multiple_replace(dic, userInput)

def multiple_replace(dic, text):
    pattern = "|".join(map(re.escape, dic.keys()))
    return re.sub(pattern, lambda m: dic[m.group()], str(text))

if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def get_data():
    ticks = pd.read_csv(ticker_index_path, dtype='str')
    na3 = ticks['name'].values.tolist()
    ind3 = ticks['id'].values.tolist()
    na = list(set(na3))
    
    
    if os.path.exists('clients_'):
        shutil.rmtree('clients_')
    os.makedirs('clients_')
    for n, i in tqdm(zip(na3, ind3)):
        rand = np.random.randint(10)
        if len(str(i)) < 5:
            continue
        TSE_CLIENT_TYPE_DATA_URL = "http://old.tsetmc.com/tsev2/data/clienttype.aspx?i={}"
        url = TSE_CLIENT_TYPE_DATA_URL.format(i)
        with requests_retry_session() as session:
            response = session.get(url, timeout=8)
        data = response.text.split(";")
        data = [row.split(",") for row in data]
        cl = pd.DataFrame(data)
        if len(cl) < 10:
            continue
        cl.columns = ["date", "individual_buy_count", "corporate_buy_count", "individual_sell_count",
                      "corporate_sell_count", "individual_buy_vol", "corporate_buy_vol", "individual_sell_vol",
                      "corporate_sell_vol", "individual_buy_value", "corporate_buy_value", "individual_sell_value",
                      "corporate_sell_value"]
        cl.to_csv(f'clients_/{n}_{rand}.csv', index=False)
    
    
    if os.path.exists('clients_new'):
        shutil.rmtree('clients_new')
    os.makedirs('clients_new')
    unis = []
    names = []
    for f in tqdm(glob('clients_/*.csv')):
        fn = f.split('\\')[1].split('_')[0].strip(' ')
        if fn.endswith("ح"):
            continue
        if fn in unis:
            idx = unis.index(fn)
            data = pd.concat([pd.read_csv(names[idx]), pd.read_csv(f)])
            data.to_csv(f'clients_new/{fn}.csv')
        else:
            names.append(f)
            unis.append(f.split('\\')[1].split('_')[0].strip(' '))
            data = pd.read_csv(f)
            data.to_csv(f'clients_new/{fn}.csv')    
    
   
    if os.path.exists('tickers_data'):
        shutil.rmtree('tickers_data')
    for n in tqdm(na):
        if n.endswith("ح"):
            continue
        try:
            tse.download(symbols=n, adjust=True, write_to_csv=True, include_jdate=True)
        except:
            print('error on :', n)
            continue
    
   
    info = pd.read_csv(new_info_path, encoding='utf-8')
    info.columns = ['code', 'group', 'indus', 'index', 'en_symbol', 'latin', 'fasymbol', 'name']
    
    
    if os.path.exists('single_tick'):
        shutil.rmtree('single_tick')
    os.makedirs('single_tick')
    for f in tqdm(na):
        try:
            f1 = 'tickers_data/' + f + '-ت.csv'
            f2 = 'clients_new/' + f + '.csv'
            df1 = pd.read_csv(f1)
            df1['date'] = df1['date'].apply(lambda x: x.replace('-', '')).astype(int)
            df2 = pd.read_csv(f2)
            df2 = df2.drop('Unnamed: 0', axis=1)
            df3 = df1.merge(df2, on='date', how='left')
            df3['fasymbol'] = f
            df3['fasymbol'] = df3['fasymbol'].apply(clean_sentence)
            info['fasymbol'] = info['fasymbol'].apply(clean_sentence)
            df3 = df3.merge(info, on='fasymbol', how='left')
            df3 = df3.dropna(subset=['individual_buy_count', 'corporate_buy_count', 'individual_sell_count',
                                     'corporate_sell_count', 'individual_buy_vol', 'corporate_buy_vol',
                                     'individual_sell_vol', 'corporate_sell_vol', 'individual_buy_value',
                                     'corporate_buy_value', 'individual_sell_value', 'corporate_sell_value'])
            df3.to_csv(f'single_tick/{f}.csv', index=False)
        except:
            pass

   
    for i, g in enumerate(glob("single_tick/*")):
        d = pd.read_csv(g)
        if i == 0:
            dff = d.copy()
        else:
            dff = pd.concat([dff, d])

  
    dff.columns = ['date_m', 'first_price', 'max_price', 'min_price', 'end_price', 'trade_value', 'trade_volume', 'trade_count',
                   'yesterday_price', 'last_price', 'date_sh', 'person_buy_count', 'Legal_buy_count', 'person_sell_count',
                   'Legal_sell_count', 'person_buy_volume', 'Legal_buy_volume', 'person_sell_volume', 'Legal_sell_volume',
                   'person_buy_value', 'Legal_buy_value', 'person_sell_value', 'Legal_sell_value',
                   'fa_symbol', 'en_symbol_12_digit_code', 'sub_industry_code', 'industry_code', 'index', 'en_symbol', 'en_name', 'fa_name']
    
  
    dff['person_buy_avg_price'] = dff['person_buy_value'] / (dff['person_buy_volume'] + 1)
    dff['person_sell_avg_price'] = dff['person_sell_value'] / (dff['person_sell_volume'] + 1)
    dff['Legal_buy_avg_price'] = dff['Legal_buy_value'] / (dff['Legal_buy_volume'] + 1)
    dff['Legal_sell_avg_price'] = dff['Legal_sell_value'] / (dff['Legal_sell_volume'] + 1)
    dff['person_ownership_change'] = dff['person_sell_volume'] - dff['person_buy_volume']
    dff['Legal_ownership_change'] = dff['Legal_sell_volume'] - dff['Legal_buy_volume']
    
    return dff


dff = get_data()
output_file = r'D:\Desktop\Time\alldata.csv'
dff.to_csv(output_file, index=False)
print(f'فایل با موفقیت در {output_file} ذخیره شد.')


