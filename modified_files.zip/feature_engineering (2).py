
import pandas as pd
import numpy as np
import re
from pandas_ta import macd, atr, rsi, ema, stoch, bbands


input_file_path = r"D:\Desktop\Time\alldata.csv"
output_file_path = r"D:\Desktop\Time\features_added.csv"

def fe(df, train=False):
    
   
    df['date_m'] = pd.to_datetime(df['date_m'], format="%Y%m%d")

    
    if 'en_symbol_12_digit_code' not in df.columns:
        raise KeyError("ستون 'en_symbol_12_digit_code' در داده‌ها موجود نیست.")
    
   
    macd_ind = df.groupby('en_symbol_12_digit_code').apply(lambda x: pd.concat([x['date_m'], x['en_symbol_12_digit_code'], macd(x['last_price'])], axis=1)).reset_index(drop=True)
    atr_ind = df.groupby('en_symbol_12_digit_code').apply(lambda x: pd.concat([x['date_m'], x['en_symbol_12_digit_code'], atr(x['max_price'], x['min_price'], x['last_price'], length=14)], axis=1)).reset_index(drop=True)
    rsi_ind = df.groupby('en_symbol_12_digit_code').apply(lambda x: pd.concat([x['date_m'], x['en_symbol_12_digit_code'], rsi(x['last_price'])], axis=1)).reset_index(drop=True)
    ema_6_ind = df.groupby('en_symbol_12_digit_code').apply(lambda x: pd.concat([x['date_m'], x['en_symbol_12_digit_code'], ema(x['last_price'], length=6)], axis=1)).reset_index(drop=True)
    ema_9_ind = df.groupby('en_symbol_12_digit_code').apply(lambda x: pd.concat([x['date_m'], x['en_symbol_12_digit_code'], ema(x['last_price'], length=9)], axis=1)).reset_index(drop=True)
    ema_12_ind = df.groupby('en_symbol_12_digit_code').apply(lambda x: pd.concat([x['date_m'], x['en_symbol_12_digit_code'], ema(x['last_price'], length=12)], axis=1)).reset_index(drop=True)
    ema_24_ind = df.groupby('en_symbol_12_digit_code').apply(lambda x: pd.concat([x['date_m'], x['en_symbol_12_digit_code'], ema(x['last_price'], length=24)], axis=1)).reset_index(drop=True)
    stoch_ind = df.groupby('en_symbol_12_digit_code').apply(lambda x: pd.concat([x['date_m'], x['en_symbol_12_digit_code'], stoch(x['max_price'], x['min_price'], x['last_price'])], axis=1)).reset_index(drop=True)
    bbands_ind = df.groupby('en_symbol_12_digit_code').apply(lambda x: pd.concat([x['date_m'], x['en_symbol_12_digit_code'], bbands(x['last_price'])], axis=1)).reset_index(drop=True)
    
    
    calc_indicator = pd.concat([macd_ind, atr_ind, rsi_ind, ema_6_ind, ema_9_ind, ema_12_ind, ema_24_ind, stoch_ind, bbands_ind], axis=1)
    calc_indicator = calc_indicator.loc[:, ~calc_indicator.columns.duplicated()]
    
  
    calc_indicator.reset_index(drop=True, inplace=True)
    df.reset_index(drop=True, inplace=True)

    
    eps = 0.0001
    df["new_trade_volume"] = (df["trade_volume"] + eps) / (df["end_price"] + eps)
    df["new_Legal_buy_volume"] = (df["Legal_buy_volume"] + eps) / (df["end_price"] + eps)
    df["new_person_buy_volume"] = (df["person_buy_volume"] + eps) / (df["end_price"] + eps)

   
    df["new_first_price"] = (df["first_price"] + eps) / (df["yesterday_price"] + eps)
    df["new_last_price"] = (df["last_price"] + eps) / (df["yesterday_price"] + eps)
    df["new_min_price"] = (df["min_price"] + eps) / (df["yesterday_price"] + eps)
    df["new_max_price"] = (df["max_price"] + eps) / (df["yesterday_price"] + eps)
    df["new_end_price"] = (df["end_price"] + eps) / (df["yesterday_price"] + eps)

   
    df["new_person_buy_avg_price"] = (df["person_buy_avg_price"] + eps) / (df["max_price"] + eps)
    df["new_Legal_buy_avg_price"] = (df["Legal_buy_avg_price"] + eps) / (df["max_price"] + eps)
    df["new_person_sell_avg_price"] = (df["person_sell_avg_price"] + eps) / (df["max_price"] + eps)
    df["new_Legal_sell_avg_price"] = (df["Legal_sell_avg_price"] + eps) / (df["max_price"] + eps)

   
    df['legal_enter_money'] = (df['Legal_buy_volume'] - df['Legal_sell_volume'] + eps) / (df['trade_volume'] + eps)
    df['person_enter_money'] = (df['person_buy_volume'] - df['person_sell_volume'] + eps) / (df['trade_volume'] + eps)
    df['buy_per_person'] = df['person_buy_volume'] / (df['person_buy_count'] + eps) / (df['trade_volume'] + eps)
    df['sell_per_person'] = df['person_sell_volume'] / (df['person_sell_count'] + eps) / (df['trade_volume'] + eps)
    df['buy_per_legal'] = df['Legal_buy_volume'] / (df['Legal_buy_count'] + eps) / (df['trade_volume'] + eps)
    df['sell_per_legal'] = df['Legal_sell_volume'] / (df['Legal_sell_count'] + eps) / (df['trade_volume'] + eps)
    df['person_power'] = df['buy_per_person'] - df['sell_per_person']
    df['legal_power'] = df['buy_per_legal'] - df['sell_per_legal']
    df['end_price_diff_last_price'] = (df['new_end_price'] + eps) - (df['new_last_price'] + eps)

   
    df = df.loc[(df["new_last_price"] > 0.7) & (df["new_last_price"] < 1.3), :]

   
    g_feature_list = ['new_last_price', 'legal_enter_money', 'person_enter_money', 'person_power', 'legal_power', 'new_trade_volume']
    g_window_list = [3, 7, 14, 30]
    
    output_dict = {}
    for feature in g_feature_list:
        for window in g_window_list:
            output_dict[f'{feature}_{window}_mean'] = df.groupby('en_symbol_12_digit_code')[feature].rolling(window).mean().reset_index(level=0, drop=True)
            output_dict[f'{feature}_{window}_std'] = df.groupby('en_symbol_12_digit_code')[feature].rolling(window).std().reset_index(level=0, drop=True)

    agg_df = pd.DataFrame(output_dict)
    agg_df.reset_index(inplace=True)

    
    df = pd.concat([df.reset_index(drop=True), agg_df], axis=1)

    
    if train:
        df['max_price_5_max'] = df.groupby('en_symbol_12_digit_code')['max_price'].rolling(3).max().reset_index(level=0, drop=True).shift(-3)
        df['end_price_5'] = df.groupby('en_symbol_12_digit_code')['end_price'].rolling(1).mean().reset_index(level=0, drop=True).shift(-3)
        df['target_max'] = df['max_price_5_max'] / df['first_price']
        df['target_end'] = df['end_price_5'] / df['first_price']
    
   
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(axis=0)

   
    print("ستون‌های نهایی داده‌ها:")
    print(df.columns.tolist())
    
    return df


df = pd.read_csv(input_file_path)
features_df = fe(df, train=True)
features_df.to_csv(output_file_path, index=False)
print(f'فایل جدید با ویژگی‌های اضافه شده در {output_file_path} ذخیره شد.')



